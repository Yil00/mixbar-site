// MixBar — volume par onglet : applique un facteur à tous les éléments <video>/<audio> de la page.
// Fichier identique dans chromium/ et firefox/.
"use strict";

(() => {
  const VERSION = "1.7.3";
  const INSTANCE = "__mixbarVolumeInstance";
  const api = globalThis.browser ?? globalThis.chrome;

  // Après une mise à jour de l'extension, l'ancienne copie du script reste vivante dans la page :
  // on l'arrête avant de prendre le relais (sinon deux copies se disputent le volume).
  const previous = globalThis[INSTANCE];
  if (previous?.version === VERSION) return;
  previous?.teardown?.();

  let gain = 1;
  // Muet imposé par MixBar (Safari n'a pas de muet d'onglet : on coupe les lecteurs de la page).
  // null = MixBar ne touche pas à `muted`.
  let forcedMute = null;
  // Même courbe que les curseurs d'app de MixBar (VolumeScale.gain) : cubique sous 100 % (50 % doit
  // « sonner » à moitié), linéaire au-dessus pour un boost prévisible, jusqu'à 200 %.
  const factor = () => (gain < 1 ? gain * gain * gain : Math.min(gain, 2));

  // Boost au-delà de 100 % : `element.volume` plafonne à 1, il faut passer par Web Audio.
  // Brancher un lecteur sur un AudioContext est irréversible ; deux garde-fous :
  // - l'AudioContext doit démarrer (politique d'autolecture), sinon le lecteur deviendrait muet ;
  // - le média doit venir du site ou d'un blob (YouTube, Twitch) : un média d'une autre origine
  //   sans CORS ressortirait en silence.
  let audioContext = null;
  const boosters = new WeakMap(); // lecteur → GainNode
  let boostBlocked = false;
  // Raison du dernier refus, remontée dans le diagnostic : origin, unsupported, autoplay, taken.
  let boostBlockedReason = null;

  function canRoute(media) {
    // Flux construit par la page (MediaSource, MediaStream via srcObject — Twitch) : même origine.
    if (media.srcObject) return true;
    const source = media.currentSrc || media.src || "";
    if (!source) return false;
    if (source.startsWith("blob:") || source.startsWith("data:")) return true;
    try {
      return new URL(source, location.href).origin === location.origin || Boolean(media.crossOrigin);
    } catch {
      return false;
    }
  }

  async function ensureBooster(media) {
    if (boosters.has(media)) return boosters.get(media);
    if (!canRoute(media)) {
      boostBlockedReason = "origin";
      return null;
    }
    const Context = globalThis.AudioContext ?? globalThis.webkitAudioContext;
    if (!Context) {
      boostBlockedReason = "unsupported";
      return null;
    }
    try {
      audioContext ??= new Context();
      if (audioContext.state !== "running") await audioContext.resume();
    } catch {}
    if (audioContext?.state !== "running") {
      boostBlockedReason = "autoplay";
      return null;
    }
    if (boosters.has(media)) return boosters.get(media);
    try {
      const node = audioContext.createGain();
      audioContext.createMediaElementSource(media).connect(node).connect(audioContext.destination);
      boosters.set(media, node);
      return node;
    } catch {
      // Lecteur déjà branché ailleurs par le site : on reste à 100 %.
      boostBlockedReason = "taken";
      return null;
    }
  }

  // Volume voulu par la page (son propre curseur), stocké sur l'élément (attribut data-) pour
  // survivre au remplacement du script : une nouvelle copie repart de la vraie valeur.
  function pageVolume(media) {
    const stored = parseFloat(media.dataset.mixbarPageVolume);
    return Number.isFinite(stored) ? stored : null;
  }
  function setPageVolume(media, value) {
    media.dataset.mixbarPageVolume = String(value);
  }

  // Dernière valeur écrite par MixBar : un volumechange qui la porte est notre propre écho.
  // (Un drapeau levé par minuteur ne suffit pas : l'événement peut arriver après, le volume
  // réduit était alors pris pour celui de la page, puis réduit encore → silence définitif.)
  const lastApplied = new WeakMap();

  function apply(media) {
    if (pageVolume(media) === null) setPageVolume(media, media.volume);
    const booster = boosters.get(media);
    // Lecteur branché : tout le volume passe par le GainNode, le lecteur reste à 1 (que le navigateur
    // applique ou non `volume` avant Web Audio, le résultat est le même).
    const target = booster ? 1 : Math.min(1, Math.max(0, pageVolume(media) * factor()));
    lastApplied.set(media, target);
    if (Math.abs(media.volume - target) > 1e-4) media.volume = target;
    if (booster) booster.gain.value = pageVolume(media) * factor();
    if (forcedMute !== null && media.muted !== forcedMute) media.muted = forcedMute;
    if (!booster && factor() > 1) {
      ensureBooster(media).then((node) => {
        boostBlocked = !node;
        if (node) apply(media);
        else report();
      });
    }
    report();
  }

  function applyAll() {
    document.querySelectorAll("video, audio").forEach(apply);
    report();
  }

  // Chrome et Firefox exposent `runtime.id` aux scripts de contenu, et le retirent quand l'extension
  // est rechargée (copie orpheline). Safari ne l'expose pas : on ne peut pas détecter l'orphelin.
  const hasRuntimeID = (() => {
    try {
      return Boolean(api.runtime?.id);
    } catch {
      return false;
    }
  })();

  function alive() {
    if (!hasRuntimeID) return Boolean(api?.runtime);
    try {
      return Boolean(api.runtime?.id);
    } catch {
      return false;
    }
  }

  // Le site change son propre volume (curseur YouTube) : on retient sa valeur et on réapplique le facteur.
  function onVolumeChange(event) {
    const media = event.target;
    if (!(media instanceof HTMLMediaElement)) return;
    if (!alive()) return teardown();
    const ours = lastApplied.get(media);
    if (ours !== undefined && Math.abs(media.volume - ours) < 1e-3) {
      // Le site a peut-être réactivé le son d'un lecteur coupé par MixBar : on recoupe.
      if (forcedMute === true && !media.muted) media.muted = true;
      return;
    }
    setPageVolume(media, media.volume);
    apply(media);
  }

  // Nouveaux lecteurs (lecture lancée, éléments créés à la volée).
  function onMediaEvent(event) {
    if (!(event.target instanceof HTMLMediaElement)) return;
    if (!alive()) return teardown();
    if (event.type === "play" && !event.target.muted) lastPlayed = event.target;
    if (event.type === "pause" || event.type === "ended") return report();
    apply(event.target);
  }

  // Dernier lecteur lancé : c'est lui qu'on relance après une pause (pas les aperçus muets).
  let lastPlayed = null;

  const isPlaying = (media) => !media.paused && !media.ended;

  // Lecture / pause demandée depuis MixBar.
  function togglePlayback(action) {
    const media = [...document.querySelectorAll("video, audio")];
    const playing = media.filter(isPlaying);
    const shouldPause = action === "pause" || (action === "toggle" && playing.length > 0);
    if (shouldPause) {
      playing.forEach((element) => element.pause());
    } else {
      const target = (lastPlayed?.isConnected ? lastPlayed : null)
        ?? media.filter((element) => element.currentTime > 0 && !element.ended)[0]
        ?? media.sort((a, b) => (b.clientWidth * b.clientHeight) - (a.clientWidth * a.clientHeight))[0];
      Promise.resolve(target?.play()).catch(() => {});
    }
    report();
  }

  function onMessage(message) {
    if (message?.type === "mixbar-volume") {
      gain = Number(message.value);
      applyAll();
    } else if (message?.type === "mixbar-mute") {
      forcedMute = Boolean(message.muted);
      applyAll();
      // Réactivé : on rend la main au site pour les prochains lecteurs.
      if (!forcedMute) forcedMute = null;
    } else if (message?.type === "mixbar-playback") {
      togglePlayback(message.action);
    }
  }

  // Diagnostic remonté à MixBar : nombre de lecteurs trouvés et volume effectif du premier.
  let reportTimer = null;
  function report() {
    clearTimeout(reportTimer);
    reportTimer = setTimeout(() => {
      if (!alive()) return;
      const media = [...document.querySelectorAll("video, audio")];
      if (media.length === 0 && window !== window.top) return;
      Promise.resolve(api.runtime.sendMessage({
        type: "mixbar-media",
        count: media.length,
        effective: media[0]?.volume ?? null,
        playing: media.some(isPlaying),
        // « blocked » : boost demandé mais impossible (autolecture, média d'une autre origine).
        boost: factor() > 1 ? (media.some((element) => boosters.has(element)) ? "active" : boostBlocked ? "blocked" : "pending") : "none",
        boostBlockedReason,
        // Une vidéo en pause au milieu peut être relancée : l'onglet reste dans MixBar.
        resumable: media.some((element) => element.paused && element.currentTime > 0 && !element.ended),
      })).catch(() => {});
    }, 200);
  }

  function teardown() {
    document.removeEventListener("volumechange", onVolumeChange, true);
    document.removeEventListener("play", onMediaEvent, true);
    document.removeEventListener("loadedmetadata", onMediaEvent, true);
    document.removeEventListener("pause", onMediaEvent, true);
    document.removeEventListener("ended", onMediaEvent, true);
    try {
      api.runtime.onMessage.removeListener(onMessage);
    } catch {}
    clearTimeout(reportTimer);
    clearInterval(heartbeat);
    if (globalThis[INSTANCE]?.teardown === teardown) delete globalThis[INSTANCE];
  }

  document.addEventListener("volumechange", onVolumeChange, true);
  document.addEventListener("play", onMediaEvent, true);
  document.addEventListener("loadedmetadata", onMediaEvent, true);
  document.addEventListener("pause", onMediaEvent, true);
  document.addEventListener("ended", onMediaEvent, true);
  api.runtime.onMessage.addListener(onMessage);
  globalThis[INSTANCE] = { version: VERSION, teardown };

  // Au chargement, l'arrière-plan rappelle le volume déjà choisi pour cet onglet. Le premier
  // rapport part quoi qu'il arrive : une vidéo déjà en lecture ne déclenche aucun événement.
  Promise.resolve(api.runtime.sendMessage({ type: "mixbar-hello" }))
    .then((response) => {
      if (typeof response?.volume === "number") gain = response.volume;
      if (response?.muted === true) forcedMute = true;
    })
    .catch(() => {})
    .finally(applyAll);

  // Rapport périodique tant que la page a des lecteurs : l'arrière-plan (Safari surtout) peut
  // avoir été rechargé et avoir tout oublié.
  const heartbeat = setInterval(() => {
    if (!alive()) return teardown();
    if (document.querySelector("video, audio")) report();
  }, 3000);
})();
