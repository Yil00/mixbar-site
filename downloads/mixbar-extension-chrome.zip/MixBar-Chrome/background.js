// MixBar — pont entre les onglets du navigateur et l'app MixBar (native messaging).
// Fichier identique dans chromium/ et firefox/ : modifier les deux (voir BrowserExtension.bundle/README.md).
"use strict";

const api = globalThis.browser ?? globalThis.chrome;
const HOST = "com.bluevision.mixbar";
let port = null;
// Volume par onglet (0…1), conservé dans storage.session : le service worker peut être endormi.
let volumes = {};
// Diagnostic par onglet renvoyé par le script de contenu : { count, effective }.
const mediaInfo = {};
// Dernier instant où chaque onglet était sonore : un onglet baissé à presque rien cesse d'être
// « audible » pour le navigateur, mais doit rester dans MixBar pour pouvoir être remonté.
const lastAudible = {};
const AUDIBLE_GRACE_MS = 120000;
const volumesLoaded = api.storage.session.get("volumes").then((stored) => {
  volumes = stored.volumes ?? {};
});

function saveVolumes() {
  api.storage.session.set({ volumes });
}

function sendVolume(tabId) {
  const value = volumes[tabId] ?? 1;
  Promise.resolve(api.tabs.sendMessage(tabId, { type: "mixbar-volume", value })).catch(() => {});
}

function connect() {
  if (port) return;
  try {
    port = api.runtime.connectNative(HOST);
  } catch (error) {
    port = null;
    return;
  }
  port.onMessage.addListener(onCommand);
  port.onDisconnect.addListener(() => {
    port = null;
  });
  pushTabs();
}

// Onglets qui jouent du son, ou coupés (pour pouvoir les réactiver depuis MixBar).
async function pushTabs() {
  if (!port) return connect();
  await volumesLoaded;
  const tabs = await api.tabs.query({});
  const now = Date.now();
  tabs.forEach((tab) => {
    if (tab.audible) lastAudible[tab.id] = now;
  });
  const list = tabs
    .filter((tab) => tab.audible || tab.mutedInfo?.muted || (volumes[tab.id] ?? 1) !== 1
      || now - (lastAudible[tab.id] ?? 0) < AUDIBLE_GRACE_MS
      || (mediaInfo[tab.id]?.resumable && lastAudible[tab.id] !== undefined))
    .map((tab) => ({
      id: tab.id,
      windowId: tab.windowId,
      title: tab.title || "",
      url: tab.url || "",
      audible: Boolean(tab.audible),
      muted: Boolean(tab.mutedInfo?.muted),
      volume: volumes[tab.id] ?? 1,
      mediaCount: mediaInfo[tab.id]?.count ?? -1,
      effectiveVolume: mediaInfo[tab.id]?.effective ?? null,
      playing: mediaInfo[tab.id]?.playing ?? null,
      boost: mediaInfo[tab.id]?.boost ?? "none",
      boostBlockedReason: mediaInfo[tab.id]?.boostBlockedReason ?? null,
      incognito: Boolean(tab.incognito),
    }));
  try {
    port.postMessage({ type: "tabs", version: api.runtime.getManifest().version, tabs: list });
  } catch (error) {
    port = null;
  }
}

let pushTimer = null;

// Se recharger depuis le disque n'a de sens que pour une extension chargée en mode développeur depuis
// le dossier que MixBar tient à jour. Installée depuis un store, ou chargée depuis un zip téléchargé,
// elle se rechargerait à l'identique… puis recommencerait à chaque connexion : une seule tentative par
// version, et jamais hors du mode développeur.
async function reloadFromDiskOnce(version) {
  try {
    const self = await api.management.getSelf();
    if (self.installType !== "development") return;
  } catch {
    return;
  }
  const { reloadedFor } = await api.storage.local.get("reloadedFor");
  if (reloadedFor === version) return;
  await api.storage.local.set({ reloadedFor: version });
  api.runtime.reload();
}

async function onCommand(message) {
  // MixBar annonce la version de l'extension qu'il embarque : si elle est plus récente que
  // celle qui tourne, on se recharge depuis le disque (une extension non empaquetée ne le fait pas seule).
  if (message.type === "hello") {
    const running = api.runtime.getManifest().version;
    if (message.extensionVersion && message.extensionVersion !== running) reloadFromDiskOnce(message.extensionVersion);
    return;
  }
  if (message.type === "volume") {
    await volumesLoaded;
    const value = Math.min(2, Math.max(0, Number(message.value)));
    if (value === 1) delete volumes[message.tabId];
    else volumes[message.tabId] = value;
    saveVolumes();
    sendVolume(message.tabId);
    // Un curseur glissé envoie des dizaines de commandes : un seul retour d'état à la fin.
    clearTimeout(pushTimer);
    pushTimer = setTimeout(pushTabs, 300);
    return;
  }
  if (message.type === "playback") {
    Promise.resolve(api.tabs.sendMessage(message.tabId, { type: "mixbar-playback", action: message.action ?? "toggle" }))
      .catch(() => {});
    return;
  }
  try {
    if (message.type === "mute") {
      await api.tabs.update(message.tabId, { muted: Boolean(message.muted) });
    } else if (message.type === "focus") {
      const tab = await api.tabs.update(message.tabId, { active: true });
      await api.windows.update(tab.windowId, { focused: true });
    }
  } finally {
    pushTabs();
  }
}

api.tabs.onUpdated.addListener((tabId, change) => {
  if (change.status === "complete" && volumes[tabId] !== undefined) sendVolume(tabId);
  if ("audible" in change || "mutedInfo" in change || "title" in change) pushTabs();
});
api.tabs.onRemoved.addListener((tabId) => {
  delete lastAudible[tabId];
  if (volumes[tabId] !== undefined) {
    delete volumes[tabId];
    saveVolumes();
  }
  pushTabs();
});

// Le script de contenu d'une page qui se charge demande le volume de son onglet.
api.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "mixbar-media" && sender.tab) {
    const known = mediaInfo[sender.tab.id];
    // Les iframes sans lecteur ne doivent pas écraser le cadre principal qui en a un.
    if (!known || message.count > 0 || sender.frameId === 0) {
      mediaInfo[sender.tab.id] = {
        count: message.count,
        effective: message.effective,
        playing: message.playing,
        resumable: message.resumable,
        boost: message.boost,
        boostBlockedReason: message.boostBlockedReason,
      };
      clearTimeout(pushTimer);
      pushTimer = setTimeout(pushTabs, 300);
    }
    return;
  }
  if (message?.type !== "mixbar-hello" || !sender.tab) return;
  volumesLoaded.then(() => sendResponse({ volume: volumes[sender.tab.id] ?? 1 }));
  return true;
});
api.tabs.onCreated.addListener(() => pushTabs());

// Reconnexion périodique : MixBar a pu être lancé après le navigateur.
api.alarms.create("mixbar-reconnect", { periodInMinutes: 0.5 });
api.alarms.onAlarm.addListener(() => (port ? pushTabs() : connect()));
api.runtime.onStartup.addListener(connect);
api.runtime.onInstalled.addListener(() => {
  connect();
  injectIntoOpenTabs();
});

// Une extension installée ou mise à jour n'atteint pas les pages déjà ouvertes : on s'y injecte.
async function injectIntoOpenTabs() {
  const tabs = await api.tabs.query({ url: ["http://*/*", "https://*/*"] });
  for (const tab of tabs) {
    api.scripting
      .executeScript({ target: { tabId: tab.id, allFrames: true }, files: ["content.js"] })
      .catch(() => {});
  }
}
connect();
